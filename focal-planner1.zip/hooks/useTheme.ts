import { useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { buildColors, Colors, THEMES, ColorTheme, COMPLETED_COLORS, CompletedColor,
         THEME_KEY, COLOR_THEME_KEY, COMPLETED_COLOR_KEY } from '../constants';

export type Theme = 'dark' | 'light';
export { Colors, ColorTheme, CompletedColor };

export function useTheme() {
  const [theme, setTheme]               = useState<Theme>('dark');
  const [colorTheme, setColorThemeState]= useState<ColorTheme>('persona');
  const [completedColor, setCompletedColorState] = useState<CompletedColor>('green');

  useEffect(() => {
    Promise.all([
      AsyncStorage.getItem(THEME_KEY),
      AsyncStorage.getItem(COLOR_THEME_KEY),
      AsyncStorage.getItem(COMPLETED_COLOR_KEY),
    ]).then(([t, c, cc]) => {
      if (t === 'light' || t === 'dark') setTheme(t);
      if (c && c in THEMES) setColorThemeState(c as ColorTheme);
      if (cc && cc in COMPLETED_COLORS) setCompletedColorState(cc as CompletedColor);
    });
  }, []);

  const toggleTheme = useCallback(async () => {
    const next: Theme = theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
    await AsyncStorage.setItem(THEME_KEY, next);
  }, [theme]);

  const setColorTheme = useCallback(async (ct: ColorTheme) => {
    setColorThemeState(ct);
    await AsyncStorage.setItem(COLOR_THEME_KEY, ct);
  }, []);

  const setCompletedColor = useCallback(async (cc: CompletedColor) => {
    setCompletedColorState(cc);
    await AsyncStorage.setItem(COMPLETED_COLOR_KEY, cc);
  }, []);

  const { accent, accentDark } = THEMES[colorTheme];
  const { hex: cHex, glow: cGlow } = COMPLETED_COLORS[completedColor];
  const colors: Colors = buildColors(theme === 'dark', accent, accentDark, cHex, cGlow);

  return { theme, colors, toggleTheme, isDark: theme === 'dark', colorTheme, setColorTheme, completedColor, setCompletedColor };
}
