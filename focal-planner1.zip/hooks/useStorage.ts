import { useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppStorage, DayData, Task, SlotId } from '../types';
import { STORAGE_KEY, SLOTS, INSTALL_DATE_KEY } from '../constants';
import { todayKey, generateId, isPast } from '../utils/dateUtils';

const defaultStorage = (): AppStorage => ({ days: {} });

export function useStorage(resetKey: number = 0) {
  const [data, setData]   = useState<AppStorage>(defaultStorage());
  const [loaded, setLoaded] = useState(false);

  // Re-run load whenever resetKey changes
  useEffect(() => {
    setLoaded(false);
    setData(defaultStorage());
    load();
  }, [resetKey]);

  const load = async () => {
    try {
      // Record install date on first launch
      let installDate = await AsyncStorage.getItem(INSTALL_DATE_KEY);
      if (!installDate) {
        installDate = todayKey();
        await AsyncStorage.setItem(INSTALL_DATE_KEY, installDate);
      }

      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed: AppStorage = JSON.parse(raw);
        const today = todayKey();
        let changed = false;
        for (const dateKey of Object.keys(parsed.days)) {
          if (dateKey >= today) continue;
          const day = parsed.days[dateKey];
          for (const slot of SLOTS) {
            const task = day.tasks[slot.id];
            if (task && task.status === 'planned') {
              day.tasks[slot.id] = { ...task, status: 'completed', completedAt: new Date().toISOString() };
              changed = true;
            }
          }
        }
        if (changed) await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(parsed));
        setData(parsed);
      }
    } catch (e) {
      console.error('Load error:', e);
    } finally {
      setLoaded(true);
    }
  };

  const save = useCallback(async (newData: AppStorage) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(newData));
      setData(newData);
    } catch (e) {
      console.error('Save error:', e);
    }
  }, []);

  const getDay = useCallback((dateKey: string): DayData =>
    data.days[dateKey] ?? { dateKey, tasks: {} }, [data]);

  const addTask = useCallback(async (dateKey: string, slotId: SlotId, title: string) => {
    const trimmed = title.trim();
    if (!trimmed) return;
    const past = isPast(dateKey);
    const task: Task = {
      id: generateId(), title: trimmed,
      status: past ? 'completed' : 'planned',
      slotId, dateKey,
      createdAt: new Date().toISOString(),
      completedAt: past ? new Date().toISOString() : undefined,
    };
    const newData: AppStorage = {
      ...data,
      days: { ...data.days, [dateKey]: { dateKey, tasks: { ...(data.days[dateKey]?.tasks ?? {}), [slotId]: task } } },
    };
    await save(newData);
  }, [data, save]);

  const editTask = useCallback(async (dateKey: string, slotId: SlotId, title: string) => {
    const trimmed = title.trim();
    if (!trimmed) return;
    const existing = data.days[dateKey]?.tasks[slotId];
    if (!existing) return;
    const newData: AppStorage = {
      ...data,
      days: { ...data.days, [dateKey]: { dateKey, tasks: { ...(data.days[dateKey]?.tasks ?? {}), [slotId]: { ...existing, title: trimmed } } } },
    };
    await save(newData);
  }, [data, save]);

  const completeTask = useCallback(async (dateKey: string, slotId: SlotId) => {
    const existing = data.days[dateKey]?.tasks[slotId];
    if (!existing) return;
    const updated: Task = {
      ...existing,
      status: existing.status === 'completed' ? 'planned' : 'completed',
      completedAt: existing.status === 'completed' ? undefined : new Date().toISOString(),
    };
    const newData: AppStorage = {
      ...data,
      days: { ...data.days, [dateKey]: { dateKey, tasks: { ...(data.days[dateKey]?.tasks ?? {}), [slotId]: updated } } },
    };
    await save(newData);
  }, [data, save]);

  const deleteTask = useCallback(async (dateKey: string, slotId: SlotId) => {
    const day = data.days[dateKey];
    if (!day) return;
    const newTasks = { ...day.tasks };
    delete newTasks[slotId];
    await save({ ...data, days: { ...data.days, [dateKey]: { dateKey, tasks: newTasks } } });
  }, [data, save]);

  const getInstallDate = useCallback(async (): Promise<string> => {
    return (await AsyncStorage.getItem(INSTALL_DATE_KEY)) ?? todayKey();
  }, []);

  const getBlockingDays = useCallback((): string[] => {
    const today = todayKey();
    const blocking: string[] = [];
    for (const dateKey of Object.keys(data.days)) {
      if (dateKey >= today) continue;
      const day = data.days[dateKey];
      const missing = SLOTS.some(s => !day.tasks[s.id]);
      if (missing) blocking.push(dateKey);
    }
    return blocking.sort();
  }, [data]);

  const canPlanFuture = useCallback((): boolean => getBlockingDays().length === 0, [getBlockingDays]);

  return { data, loaded, getDay, addTask, editTask, completeTask, deleteTask, getBlockingDays, canPlanFuture };
}
